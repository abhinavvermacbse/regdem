package com.regestratrion.regdem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegdemApplicationTests {

	@Test
	void contextLoads() {
	}

}
