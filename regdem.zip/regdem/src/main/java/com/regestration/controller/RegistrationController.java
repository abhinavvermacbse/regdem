package com.regestration.controller;



//@Re
//public class RegistrationController {
//
//	 
//}

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.regestration.model.Registrations;
import com.regestration.service.ServiceRegistration;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;




@RestController
//@RequestMapping("/api/registrations")
@CrossOrigin(origins = "*")
public class RegistrationController {
      
    @Autowired
    private ServiceRegistration  ServiceRegistration;

    // ✅ Save user registration
    @PostMapping("/register")
    public ResponseEntity<String>  registerUser(@RequestBody Registrations user, HttpServletRequest request,
    		HttpServletResponse response) {
//        boolean isRegistered = ServiceRegistration.registerUser(user);
//        if (isRegistered) {
//            return ResponseEntity.ok("User registered successfully.");
//        } else {
//            return ResponseEntity.badRequest().body("Email already exists!");
//        }
  
    	
    	System.out.println("register API HIT");
//    	System.out.println(user); 	
//        return "1000";
    	   
    	System.out.println(user);
      
        try {  
            ServiceRegistration.registerUser(user);  // ✅ Save user to database
            return ResponseEntity.ok("User registered successfully!");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Error registering user: " + e.getMessage());
        }
    	
    }    
   
    // ✅ Get all registered users
//    @GetMapping("/all")
//    public ResponseEntity<List<Registrations>> getAllUsers() {
//        List<Registrations> users =ServiceRegistration.getAllUsers();
//        return ResponseEntity.ok(users);
//    }

    // ✅ Get user by email 
//    @GetMapping("/{email}")
//    public ResponseEntity<Registrations> getUserByEmail(@PathVariable String email) {
//       // Registrations user = ServiceRegistration.getUserByEmail(email);
//        if (user != null) {
//            return ResponseEntity.ok(user);
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
   
    // ✅ Get total user count
//    @GetMapping("/count")
//    public ResponseEntity<Long> getTotalUsers() {
//        long count = ServiceRegistration.getTotalUserCount();
//        return ResponseEntity.ok(count);
//    }
}
