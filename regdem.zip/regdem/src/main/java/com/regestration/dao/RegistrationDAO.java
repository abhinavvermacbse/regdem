package com.regestration.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.regestration.repository.*;


	@Repository
	public class RegistrationDAO {
	    
	    @Autowired
	    registrationRepository registrationRepository;
        
	    // ✅ Save a user
//	    public Registrations saveUser(Registrations user) {
//	        return registrationRepository.save(user);
//	    }
//        
//	    // ✅ Get all users
//	    public List<Registrations> getAllUsers() {
//	        return registrationRepository.findAll();
//	    }
//
//	    // ✅ Find user by email
//	    public boolean existsByEmail(String email) {
//	        return registrationRepository.existsByEmail(email);
//	    }
	
	}   
