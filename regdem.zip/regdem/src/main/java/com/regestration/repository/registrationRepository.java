package com.regestration.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.regestration.model.Registrations;

@Repository
public interface registrationRepository extends JpaRepository<Registrations, Integer >  
{

	/* write your native queries here */
	

//    @Query("SELECT r FROM Registrations r WHERE r.email = :email")
//    Registrations findByEmail(@Param("email") String email);
//
//    @Query("SELECT COUNT(r) FROM Registrations r")
//    long countTotalUsers();

    boolean existsByEmail(String email);
	  
	  
}
  