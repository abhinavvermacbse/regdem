package com.regestration;  // ✅ Ensure package name is correct

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableAsync
@EnableScheduling

@EnableJpaRepositories("com.regestration.repository")


// ✅ Explicitly specify package scanning
@ComponentScan(basePackages = {"com.regestration.controller", "com.regestration.service","com.regestration.dao","com.regestration.repository", "com.regestration.bean"})
public class RegdemApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(RegdemApplication.class, args);  
    }
 
    @Override 
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(RegdemApplication.class);  // ✅ Fix method name and return correct source
    }
} 
