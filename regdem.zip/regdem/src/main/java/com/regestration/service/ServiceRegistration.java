package com.regestration.service;



import com.regestration.dao.RegistrationDAO;
import com.regestration.model.Registrations;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ServiceRegistration {

    @Autowired
    private RegistrationDAO registrationDAO;

    public String registerUser(Registrations user) {
//        if (registrationDAO.existsByEmail(user.getEmail())) {
//            return "User already exists!";
//        }
//        registrationDAO.saveUser(user);
    	
    
        return "User registered successfully!";
    }
   
 
//    // ✅ Retrieve all registered users
//    public List<Registrations> getAllUsers() {
//        return registrationRepository.findAll();
//    }
//
//    
//    // ✅ Retrieve a user by email
//    public Registrations getUserByEmail(String email) {
//        return registrationRepository.findByEmail(email);
//    }

//
//    // ✅ Count total registered users
//    public long getTotalUserCount() {
//        return registrationRepository.count();
//    }
}
